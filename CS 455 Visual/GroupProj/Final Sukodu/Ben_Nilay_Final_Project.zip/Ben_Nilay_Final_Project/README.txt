TO RUN

1. In terminal, navigate to the file

2. type ‘make’

3. skip this step if you already have puzzles to work from 
(SOME HAVE BEEN PROVIDED IN THE ‘Puzzles’ FOLDER)
go the the website ‘http://www.websudoku.com/?select=1&level=3'
choose a random puzzle and press print when you are there. 
MAKER SURE to print ‘regular’ as a .pdf and save that. 
Turn it into a .jpg using http://pdf2jpg.net/ and save in the ‘Puzzles’ folder

4.run the program in the terminal by typing 
./Proj Puzzles/SukoduXXX.jpg
(you can run the program with the given ‘Sudoku002.jpg’ and ‘Sudoku003.jpg’)

5. When the puzzle screen is the active one, press spacebar to cycle views. 

6. In case it doesn’t work, you may not be running on a macintosh. 
to fix this, in the driver you can uncomment out line 55. 
You will also need to comment out lines 59 - 81. 

After this, the result will be stored in a file called COMPLETE.jpg in the source folder. 