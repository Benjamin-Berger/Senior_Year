Date.weekdays = $w('Пн Вт Ср Чт Пт Сб Вс');
Date.months = $w('Январь Февраль Март Апрель Май Июнь Июль Август Сентябрь Октябрь Ноябрь Декабрь');

Date.first_day_of_week = 1

_translations = {
  "OK": "OK",
  "Now": "Сейчас",
  "Today": "Сегодня"
}