require 'action_web_service/container/direct_container'
require 'action_web_service/container/delegated_container'
