# Add a declarative step here for populating the DB with movies.

Given /the following movies exist/ do |movies_table|
  movies_table.hashes.each do |movie|
    Movie.create(movie)
  end
end

# Make sure that one string (regexp) occurs before or after another one
#   on the same page

Then(/^the director of "(.*?)" should be "(.*?)"$/) do |title, director|
    assert (Movie.find_by_title(title).director == director) 
end

