require 'spec_helper'

describe MoviesController, :type => :controller do
    it "render  similar movies page" do
        get :find_similar, {:id=> "1"}
       expect(response).to render_template("movies/find_similar")
    end
    
    it "return collection of movies with same director" do
        movie = Movie.find_by_title("Alien")
        movies = movie.find_similar_movies
        director = movie.director
        movies.each do |m|
            m.director.should == director
        end
    end
    
    it "should return nil" do
        Movie.find_by_title("Alien").find_similar_movies.should == nil
    end
end