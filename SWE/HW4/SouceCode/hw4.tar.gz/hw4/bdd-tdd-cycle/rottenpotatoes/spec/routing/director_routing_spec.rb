require 'spec_helper'

describe "routing to find similar movies" do
    it "routes /movies/1/find_similar to movies#find_similar" do
        expect(get: "/movies/1/find_similar").to route_to(
            controller: "movies",
            action: "find_similar",
            id: "1"
        )   
    end
end