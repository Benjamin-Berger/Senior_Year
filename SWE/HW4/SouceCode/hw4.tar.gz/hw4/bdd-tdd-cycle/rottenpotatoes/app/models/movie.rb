class Movie < ActiveRecord::Base

  attr_accessible :title, :rating, :description, :release_date, :director

  def self.all_ratings
    %w(G PG PG-13 NC-17 R)
  end
  
  def find_similar_movies
      if self.director == ""
        return nil 
      else
          return Movie.where(:director => self.director)
      end
  end
end

