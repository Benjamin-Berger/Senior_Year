#include <cstdlib>
#include <cstdio>
#include <iostream>
#include "fscrypt.h"

int main()
{
	//Hard Code in some tests for individual functions
	char text[] = "kyle";
	return 0;
}
